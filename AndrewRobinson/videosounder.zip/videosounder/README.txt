This code directory is compressed
Promoted to 
SC/projects/SC_Videosounder 
